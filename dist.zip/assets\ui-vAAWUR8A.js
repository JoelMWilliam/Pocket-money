/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function z(t){return t<0?-1:t===0?0:1}function Z(t,e,r){return(1-r)*t+r*e}function Ot(t,e,r){return r<t?t:r>e?e:r}function nt(t,e,r){return r<t?t:r>e?e:r}function ft(t){return t=t%360,t<0&&(t=t+360),t}function Lt(t,e){return ft(e-t)<=180?1:-1}function Rt(t,e){return 180-Math.abs(Math.abs(t-e)-180)}function ut(t,e){const r=t[0]*e[0][0]+t[1]*e[0][1]+t[2]*e[0][2],n=t[0]*e[1][0]+t[1]*e[1][1]+t[2]*e[1][2],a=t[0]*e[2][0]+t[1]*e[2][1]+t[2]*e[2][2];return[r,n,a]}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */const xt=[[.41233895,.35762064,.18051042],[.2126,.7152,.0722],[.01932141,.11916382,.95034478]],St=[[3.2413774792388685,-1.5376652402851851,-.49885366846268053],[-.9691452513005321,1.8758853451067872,.04156585616912061],[.05562093689691305,-.20395524564742123,1.0571799111220335]],Et=[95.047,100,108.883];function dt(t,e,r){return(255<<24|(t&255)<<16|(e&255)<<8|r&255)>>>0}function Pt(t){const e=K(t[0]),r=K(t[1]),n=K(t[2]);return dt(e,r,n)}function Mt(t){return t>>16&255}function Ct(t){return t>>8&255}function Dt(t){return t&255}function Nt(t,e,r){const n=St,a=n[0][0]*t+n[0][1]*e+n[0][2]*r,s=n[1][0]*t+n[1][1]*e+n[1][2]*r,c=n[2][0]*t+n[2][1]*e+n[2][2]*r,i=K(a),l=K(s),f=K(c);return dt(i,l,f)}function zt(t){const e=X(Mt(t)),r=X(Ct(t)),n=X(Dt(t));return ut([e,r,n],xt)}function Vt(t){const e=H(t),r=K(e);return dt(r,r,r)}function lt(t){const e=zt(t)[1];return 116*It(e/100)-16}function H(t){return 100*qt((t+16)/116)}function ht(t){return It(t/100)*116-16}function X(t){const e=t/255;return e<=.040449936?e/12.92*100:Math.pow((e+.055)/1.055,2.4)*100}function K(t){const e=t/100;let r=0;return e<=.0031308?r=e*12.92:r=1.055*Math.pow(e,1/2.4)-.055,Ot(0,255,Math.round(r*255))}function Ut(){return Et}function It(t){const e=.008856451679035631,r=24389/27;return t>e?Math.pow(t,1/3):(r*t+16)/116}function qt(t){const e=.008856451679035631,r=24389/27,n=t*t*t;return n>e?n:(116*t-16)/r}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class q{static make(e=Ut(),r=200/Math.PI*H(50)/100,n=50,a=2,s=!1){const c=e,i=c[0]*.401288+c[1]*.650173+c[2]*-.051461,l=c[0]*-.250268+c[1]*1.204414+c[2]*.045854,f=c[0]*-.002079+c[1]*.048952+c[2]*.953127,h=.8+a/10,m=h>=.9?Z(.59,.69,(h-.9)*10):Z(.525,.59,(h-.8)*10);let p=s?1:h*(1-1/3.6*Math.exp((-r-42)/92));p=p>1?1:p<0?0:p;const M=h,g=[p*(100/i)+1-p,p*(100/l)+1-p,p*(100/f)+1-p],b=1/(5*r+1),C=b*b*b*b,w=1-C,I=C*r+.1*w*w*Math.cbrt(5*r),P=H(n)/e[1],N=1.48+Math.sqrt(P),k=.725/Math.pow(P,.2),B=k,D=[Math.pow(I*g[0]*i/100,.42),Math.pow(I*g[1]*l/100,.42),Math.pow(I*g[2]*f/100,.42)],A=[400*D[0]/(D[0]+27.13),400*D[1]/(D[1]+27.13),400*D[2]/(D[2]+27.13)],x=(2*A[0]+A[1]+.05*A[2])*k;return new q(P,x,k,B,m,M,g,I,Math.pow(I,.25),N)}constructor(e,r,n,a,s,c,i,l,f,h){this.n=e,this.aw=r,this.nbb=n,this.ncb=a,this.c=s,this.nc=c,this.rgbD=i,this.fl=l,this.fLRoot=f,this.z=h}}q.DEFAULT=q.make();/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class L{constructor(e,r,n,a,s,c,i,l,f){this.hue=e,this.chroma=r,this.j=n,this.q=a,this.m=s,this.s=c,this.jstar=i,this.astar=l,this.bstar=f}distance(e){const r=this.jstar-e.jstar,n=this.astar-e.astar,a=this.bstar-e.bstar,s=Math.sqrt(r*r+n*n+a*a);return 1.41*Math.pow(s,.63)}static fromInt(e){return L.fromIntInViewingConditions(e,q.DEFAULT)}static fromIntInViewingConditions(e,r){const n=(e&16711680)>>16,a=(e&65280)>>8,s=e&255,c=X(n),i=X(a),l=X(s),f=.41233895*c+.35762064*i+.18051042*l,h=.2126*c+.7152*i+.0722*l,m=.01932141*c+.11916382*i+.95034478*l,p=.401288*f+.650173*h-.051461*m,M=-.250268*f+1.204414*h+.045854*m,g=-.002079*f+.048952*h+.953127*m,b=r.rgbD[0]*p,C=r.rgbD[1]*M,w=r.rgbD[2]*g,I=Math.pow(r.fl*Math.abs(b)/100,.42),P=Math.pow(r.fl*Math.abs(C)/100,.42),N=Math.pow(r.fl*Math.abs(w)/100,.42),k=z(b)*400*I/(I+27.13),B=z(C)*400*P/(P+27.13),D=z(w)*400*N/(N+27.13),A=(11*k+-12*B+D)/11,x=(k+B-2*D)/9,F=(20*k+20*B+21*D)/20,_=(40*k+20*B+D)/20,Y=Math.atan2(x,A)*180/Math.PI,U=Y<0?Y+360:Y>=360?Y-360:Y,v=U*Math.PI/180,tt=_*r.nbb,J=100*Math.pow(tt/r.aw,r.c*r.z),et=4/r.c*Math.sqrt(J/100)*(r.aw+4)*r.fLRoot,at=U<20.14?U+360:U,ot=.25*(Math.cos(at*Math.PI/180+2)+3.8),ct=5e4/13*ot*r.nc*r.ncb*Math.sqrt(A*A+x*x)/(F+.305),rt=Math.pow(ct,.9)*Math.pow(1.64-Math.pow(.29,r.n),.73),yt=rt*Math.sqrt(J/100),bt=yt*r.fLRoot,Tt=50*Math.sqrt(rt*r.c/(r.aw+4)),wt=(1+100*.007)*J/(1+.007*J),kt=1/.0228*Math.log(1+.0228*bt),At=kt*Math.cos(v),Bt=kt*Math.sin(v);return new L(U,yt,J,et,bt,Tt,wt,At,Bt)}static fromJch(e,r,n){return L.fromJchInViewingConditions(e,r,n,q.DEFAULT)}static fromJchInViewingConditions(e,r,n,a){const s=4/a.c*Math.sqrt(e/100)*(a.aw+4)*a.fLRoot,c=r*a.fLRoot,i=r/Math.sqrt(e/100),l=50*Math.sqrt(i*a.c/(a.aw+4)),f=n*Math.PI/180,h=(1+100*.007)*e/(1+.007*e),m=1/.0228*Math.log(1+.0228*c),p=m*Math.cos(f),M=m*Math.sin(f);return new L(n,r,e,s,c,l,h,p,M)}static fromUcs(e,r,n){return L.fromUcsInViewingConditions(e,r,n,q.DEFAULT)}static fromUcsInViewingConditions(e,r,n,a){const s=r,c=n,i=Math.sqrt(s*s+c*c),f=(Math.exp(i*.0228)-1)/.0228/a.fLRoot;let h=Math.atan2(c,s)*(180/Math.PI);h<0&&(h+=360);const m=e/(1-(e-100)*.007);return L.fromJchInViewingConditions(m,f,h,a)}toInt(){return this.viewed(q.DEFAULT)}viewed(e){const r=this.chroma===0||this.j===0?0:this.chroma/Math.sqrt(this.j/100),n=Math.pow(r/Math.pow(1.64-Math.pow(.29,e.n),.73),1/.9),a=this.hue*Math.PI/180,s=.25*(Math.cos(a+2)+3.8),c=e.aw*Math.pow(this.j/100,1/e.c/e.z),i=s*(5e4/13)*e.nc*e.ncb,l=c/e.nbb,f=Math.sin(a),h=Math.cos(a),m=23*(l+.305)*n/(23*i+11*n*h+108*n*f),p=m*h,M=m*f,g=(460*l+451*p+288*M)/1403,b=(460*l-891*p-261*M)/1403,C=(460*l-220*p-6300*M)/1403,w=Math.max(0,27.13*Math.abs(g)/(400-Math.abs(g))),I=z(g)*(100/e.fl)*Math.pow(w,1/.42),P=Math.max(0,27.13*Math.abs(b)/(400-Math.abs(b))),N=z(b)*(100/e.fl)*Math.pow(P,1/.42),k=Math.max(0,27.13*Math.abs(C)/(400-Math.abs(C))),B=z(C)*(100/e.fl)*Math.pow(k,1/.42),D=I/e.rgbD[0],A=N/e.rgbD[1],x=B/e.rgbD[2],F=1.86206786*D-1.01125463*A+.14918677*x,_=.38752654*D+.62144744*A-.00897398*x,$=-.0158415*D-.03412294*A+1.04996444*x;return Nt(F,_,$)}static fromXyzInViewingConditions(e,r,n,a){const s=.401288*e+.650173*r-.051461*n,c=-.250268*e+1.204414*r+.045854*n,i=-.002079*e+.048952*r+.953127*n,l=a.rgbD[0]*s,f=a.rgbD[1]*c,h=a.rgbD[2]*i,m=Math.pow(a.fl*Math.abs(l)/100,.42),p=Math.pow(a.fl*Math.abs(f)/100,.42),M=Math.pow(a.fl*Math.abs(h)/100,.42),g=z(l)*400*m/(m+27.13),b=z(f)*400*p/(p+27.13),C=z(h)*400*M/(M+27.13),w=(11*g+-12*b+C)/11,I=(g+b-2*C)/9,P=(20*g+20*b+21*C)/20,N=(40*g+20*b+C)/20,B=Math.atan2(I,w)*180/Math.PI,D=B<0?B+360:B>=360?B-360:B,A=D*Math.PI/180,x=N*a.nbb,F=100*Math.pow(x/a.aw,a.c*a.z),_=4/a.c*Math.sqrt(F/100)*(a.aw+4)*a.fLRoot,$=D<20.14?D+360:D,Y=1/4*(Math.cos($*Math.PI/180+2)+3.8),v=5e4/13*Y*a.nc*a.ncb*Math.sqrt(w*w+I*I)/(P+.305),tt=Math.pow(v,.9)*Math.pow(1.64-Math.pow(.29,a.n),.73),J=tt*Math.sqrt(F/100),et=J*a.fLRoot,at=50*Math.sqrt(tt*a.c/(a.aw+4)),ot=(1+100*.007)*F/(1+.007*F),st=Math.log(1+.0228*et)/.0228,ct=st*Math.cos(A),rt=st*Math.sin(A);return new L(D,J,F,_,et,at,ot,ct,rt)}xyzInViewingConditions(e){const r=this.chroma===0||this.j===0?0:this.chroma/Math.sqrt(this.j/100),n=Math.pow(r/Math.pow(1.64-Math.pow(.29,e.n),.73),1/.9),a=this.hue*Math.PI/180,s=.25*(Math.cos(a+2)+3.8),c=e.aw*Math.pow(this.j/100,1/e.c/e.z),i=s*(5e4/13)*e.nc*e.ncb,l=c/e.nbb,f=Math.sin(a),h=Math.cos(a),m=23*(l+.305)*n/(23*i+11*n*h+108*n*f),p=m*h,M=m*f,g=(460*l+451*p+288*M)/1403,b=(460*l-891*p-261*M)/1403,C=(460*l-220*p-6300*M)/1403,w=Math.max(0,27.13*Math.abs(g)/(400-Math.abs(g))),I=z(g)*(100/e.fl)*Math.pow(w,1/.42),P=Math.max(0,27.13*Math.abs(b)/(400-Math.abs(b))),N=z(b)*(100/e.fl)*Math.pow(P,1/.42),k=Math.max(0,27.13*Math.abs(C)/(400-Math.abs(C))),B=z(C)*(100/e.fl)*Math.pow(k,1/.42),D=I/e.rgbD[0],A=N/e.rgbD[1],x=B/e.rgbD[2],F=1.86206786*D-1.01125463*A+.14918677*x,_=.38752654*D+.62144744*A-.00897398*x,$=-.0158415*D-.03412294*A+1.04996444*x;return[F,_,$]}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class d{static sanitizeRadians(e){return(e+Math.PI*8)%(Math.PI*2)}static trueDelinearized(e){const r=e/100;let n=0;return r<=.0031308?n=r*12.92:n=1.055*Math.pow(r,1/2.4)-.055,n*255}static chromaticAdaptation(e){const r=Math.pow(Math.abs(e),.42);return z(e)*400*r/(r+27.13)}static hueOf(e){const r=ut(e,d.SCALED_DISCOUNT_FROM_LINRGB),n=d.chromaticAdaptation(r[0]),a=d.chromaticAdaptation(r[1]),s=d.chromaticAdaptation(r[2]),c=(11*n+-12*a+s)/11,i=(n+a-2*s)/9;return Math.atan2(i,c)}static areInCyclicOrder(e,r,n){const a=d.sanitizeRadians(r-e),s=d.sanitizeRadians(n-e);return a<s}static intercept(e,r,n){return(r-e)/(n-e)}static lerpPoint(e,r,n){return[e[0]+(n[0]-e[0])*r,e[1]+(n[1]-e[1])*r,e[2]+(n[2]-e[2])*r]}static setCoordinate(e,r,n,a){const s=d.intercept(e[a],r,n[a]);return d.lerpPoint(e,s,n)}static isBounded(e){return 0<=e&&e<=100}static nthVertex(e,r){const n=d.Y_FROM_LINRGB[0],a=d.Y_FROM_LINRGB[1],s=d.Y_FROM_LINRGB[2],c=r%4<=1?0:100,i=r%2===0?0:100;if(r<4){const l=c,f=i,h=(e-l*a-f*s)/n;return d.isBounded(h)?[h,l,f]:[-1,-1,-1]}else if(r<8){const l=c,f=i,h=(e-f*n-l*s)/a;return d.isBounded(h)?[f,h,l]:[-1,-1,-1]}else{const l=c,f=i,h=(e-l*n-f*a)/s;return d.isBounded(h)?[l,f,h]:[-1,-1,-1]}}static bisectToSegment(e,r){let n=[-1,-1,-1],a=n,s=0,c=0,i=!1,l=!0;for(let f=0;f<12;f++){const h=d.nthVertex(e,f);if(h[0]<0)continue;const m=d.hueOf(h);if(!i){n=h,a=h,s=m,c=m,i=!0;continue}(l||d.areInCyclicOrder(s,m,c))&&(l=!1,d.areInCyclicOrder(s,r,m)?(a=h,c=m):(n=h,s=m))}return[n,a]}static midpoint(e,r){return[(e[0]+r[0])/2,(e[1]+r[1])/2,(e[2]+r[2])/2]}static criticalPlaneBelow(e){return Math.floor(e-.5)}static criticalPlaneAbove(e){return Math.ceil(e-.5)}static bisectToLimit(e,r){const n=d.bisectToSegment(e,r);let a=n[0],s=d.hueOf(a),c=n[1];for(let i=0;i<3;i++)if(a[i]!==c[i]){let l=-1,f=255;a[i]<c[i]?(l=d.criticalPlaneBelow(d.trueDelinearized(a[i])),f=d.criticalPlaneAbove(d.trueDelinearized(c[i]))):(l=d.criticalPlaneAbove(d.trueDelinearized(a[i])),f=d.criticalPlaneBelow(d.trueDelinearized(c[i])));for(let h=0;h<8&&!(Math.abs(f-l)<=1);h++){const m=Math.floor((l+f)/2),p=d.CRITICAL_PLANES[m],M=d.setCoordinate(a,p,c,i),g=d.hueOf(M);d.areInCyclicOrder(s,r,g)?(c=M,f=m):(a=M,s=g,l=m)}}return d.midpoint(a,c)}static inverseChromaticAdaptation(e){const r=Math.abs(e),n=Math.max(0,27.13*r/(400-r));return z(e)*Math.pow(n,1/.42)}static findResultByJ(e,r,n){let a=Math.sqrt(n)*11;const s=q.DEFAULT,c=1/Math.pow(1.64-Math.pow(.29,s.n),.73),l=.25*(Math.cos(e+2)+3.8)*(5e4/13)*s.nc*s.ncb,f=Math.sin(e),h=Math.cos(e);for(let m=0;m<5;m++){const p=a/100,M=r===0||a===0?0:r/Math.sqrt(p),g=Math.pow(M*c,1/.9),C=s.aw*Math.pow(p,1/s.c/s.z)/s.nbb,w=23*(C+.305)*g/(23*l+11*g*h+108*g*f),I=w*h,P=w*f,N=(460*C+451*I+288*P)/1403,k=(460*C-891*I-261*P)/1403,B=(460*C-220*I-6300*P)/1403,D=d.inverseChromaticAdaptation(N),A=d.inverseChromaticAdaptation(k),x=d.inverseChromaticAdaptation(B),F=ut([D,A,x],d.LINRGB_FROM_SCALED_DISCOUNT);if(F[0]<0||F[1]<0||F[2]<0)return 0;const _=d.Y_FROM_LINRGB[0],$=d.Y_FROM_LINRGB[1],Y=d.Y_FROM_LINRGB[2],U=_*F[0]+$*F[1]+Y*F[2];if(U<=0)return 0;if(m===4||Math.abs(U-n)<.002)return F[0]>100.01||F[1]>100.01||F[2]>100.01?0:Pt(F);a=a-(U-n)*a/(2*U)}return 0}static solveToInt(e,r,n){if(r<1e-4||n<1e-4||n>99.9999)return Vt(n);e=ft(e);const a=e/180*Math.PI,s=H(n),c=d.findResultByJ(a,r,s);if(c!==0)return c;const i=d.bisectToLimit(s,a);return Pt(i)}static solveToCam(e,r,n){return L.fromInt(d.solveToInt(e,r,n))}}d.SCALED_DISCOUNT_FROM_LINRGB=[[.001200833568784504,.002389694492170889,.0002795742885861124],[.0005891086651375999,.0029785502573438758,.0003270666104008398],[.00010146692491640572,.0005364214359186694,.0032979401770712076]];d.LINRGB_FROM_SCALED_DISCOUNT=[[1373.2198709594231,-1100.4251190754821,-7.278681089101213],[-271.815969077903,559.6580465940733,-32.46047482791194],[1.9622899599665666,-57.173814538844006,308.7233197812385]];d.Y_FROM_LINRGB=[.2126,.7152,.0722];d.CRITICAL_PLANES=[.015176349177441876,.045529047532325624,.07588174588720938,.10623444424209313,.13658714259697685,.16693984095186062,.19729253930674434,.2276452376616281,.2579979360165119,.28835063437139563,.3188300904430532,.350925934958123,.3848314933096426,.42057480301049466,.458183274052838,.4976837250274023,.5391024159806381,.5824650784040898,.6277969426914107,.6751227633498623,.7244668422128921,.775853049866786,.829304845476233,.8848452951698498,.942497089126609,1.0022825574869039,1.0642236851973577,1.1283421258858297,1.1946592148522128,1.2631959812511864,1.3339731595349034,1.407011200216447,1.4823302800086415,1.5599503113873272,1.6398909516233677,1.7221716113234105,1.8068114625156377,1.8938294463134073,1.9832442801866852,2.075074464868551,2.1693382909216234,2.2660538449872063,2.36523901573795,2.4669114995532007,2.5710888059345764,2.6777882626779785,2.7870270208169257,2.898822059350997,3.0131901897720907,3.1301480604002863,3.2497121605402226,3.3718988244681087,3.4967242352587946,3.624204428461639,3.754355295633311,3.887192587735158,4.022731918402185,4.160988767090289,4.301978482107941,4.445716283538092,4.592217266055746,4.741496401646282,4.893568542229298,5.048448422192488,5.20615066083972,5.3666897647573375,5.5300801301023865,5.696336044816294,5.865471690767354,6.037501145825082,6.212438385869475,6.390297286737924,6.571091626112461,6.7548350853498045,6.941541251256611,7.131223617812143,7.323895587840543,7.5195704746346665,7.7182615035334345,7.919981813454504,8.124744458384042,8.332562408825165,8.543448553206703,8.757415699253682,8.974476575321063,9.194643831691977,9.417930041841839,9.644347703669503,9.873909240696694,10.106627003236781,10.342513269534024,10.58158024687427,10.8238400726681,11.069304815507364,11.317986476196008,11.569896988756009,11.825048221409341,12.083451977536606,12.345119996613247,12.610063955123938,12.878295467455942,13.149826086772048,13.42466730586372,13.702830557985108,13.984327217668513,14.269168601521828,14.55736596900856,14.848930523210871,15.143873411576273,15.44220572664832,15.743938506781891,16.04908273684337,16.35764934889634,16.66964922287304,16.985093187232053,17.30399201960269,17.62635644741625,17.95219714852476,18.281524751807332,18.614349837764564,18.95068293910138,19.290534541298456,19.633915083172692,19.98083495742689,20.331304511189067,20.685334046541502,21.042933821039977,21.404114048223256,21.76888489811322,22.137256497705877,22.50923893145328,22.884842241736916,23.264076429332462,23.6469514538663,24.033477234264016,24.42366364919083,24.817520537484558,25.21505769858089,25.61628489293138,26.021211842414342,26.429848230738664,26.842203703840827,27.258287870275353,27.678110301598522,28.10168053274597,28.529008062403893,28.96010235337422,29.39497283293396,29.83362889318845,30.276079891419332,30.722335150426627,31.172403958865512,31.62629557157785,32.08401920991837,32.54558406207592,33.010999283389665,33.4802739966603,33.953417292456834,34.430438229418264,34.911345834551085,35.39614910352207,35.88485700094671,36.37747846067349,36.87402238606382,37.37449765026789,37.87891309649659,38.38727753828926,38.89959975977785,39.41588851594697,39.93615253289054,40.460400508064545,40.98864111053629,41.520882981230194,42.05713473317016,42.597404951718396,43.141702194811224,43.6900349931913,44.24241185063697,44.798841244188324,45.35933162437017,45.92389141541209,46.49252901546552,47.065252796817916,47.64207110610409,48.22299226451468,48.808024568002054,49.3971762874833,49.9904556690408,50.587870934119984,51.189430279724725,51.79514187861014,52.40501387947288,53.0190544071392,53.637271562750364,54.259673423945976,54.88626804504493,55.517063457223934,56.15206766869424,56.79128866487574,57.43473440856916,58.08241284012621,58.734331877617365,59.39049941699807,60.05092333227251,60.715611475655585,61.38457167773311,62.057811747619894,62.7353394731159,63.417162620860914,64.10328893648692,64.79372614476921,65.48848194977529,66.18756403501224,66.89098006357258,67.59873767827808,68.31084450182222,69.02730813691093,69.74813616640164,70.47333615344107,71.20291564160104,71.93688215501312,72.67524319850172,73.41800625771542,74.16517879925733,74.9167682708136,75.67278210128072,76.43322770089146,77.1981124613393,77.96744375590167,78.74122893956174,79.51947534912904,80.30219030335869,81.08938110306934,81.88105503125999,82.67721935322541,83.4778813166706,84.28304815182372,85.09272707154808,85.90692527145302,86.72564993000343,87.54890820862819,88.3767072518277,89.2090541872801,90.04595612594655,90.88742016217518,91.73345337380438,92.58406282226491,93.43925555268066,94.29903859396902,95.16341895893969,96.03240364439274,96.9059996312159,97.78421388448044,98.6670533535366,99.55452497210776];/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class R{static from(e,r,n){return new R(d.solveToInt(e,r,n))}static fromInt(e){return new R(e)}toInt(){return this.argb}get hue(){return this.internalHue}set hue(e){this.setInternalState(d.solveToInt(e,this.internalChroma,this.internalTone))}get chroma(){return this.internalChroma}set chroma(e){this.setInternalState(d.solveToInt(this.internalHue,e,this.internalTone))}get tone(){return this.internalTone}set tone(e){this.setInternalState(d.solveToInt(this.internalHue,this.internalChroma,e))}constructor(e){this.argb=e;const r=L.fromInt(e);this.internalHue=r.hue,this.internalChroma=r.chroma,this.internalTone=lt(e),this.argb=e}setInternalState(e){const r=L.fromInt(e);this.internalHue=r.hue,this.internalChroma=r.chroma,this.internalTone=lt(e),this.argb=e}inViewingConditions(e){const n=L.fromInt(this.toInt()).xyzInViewingConditions(e),a=L.fromXyzInViewingConditions(n[0],n[1],n[2],q.make());return R.from(a.hue,a.chroma,ht(n[1]))}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class mt{static harmonize(e,r){const n=R.fromInt(e),a=R.fromInt(r),s=Rt(n.hue,a.hue),c=Math.min(s*.5,15),i=ft(n.hue+c*Lt(n.hue,a.hue));return R.from(i,n.chroma,n.tone).toInt()}static hctHue(e,r,n){const a=mt.cam16Ucs(e,r,n),s=L.fromInt(a),c=L.fromInt(e);return R.from(s.hue,c.chroma,lt(e)).toInt()}static cam16Ucs(e,r,n){const a=L.fromInt(e),s=L.fromInt(r),c=a.jstar,i=a.astar,l=a.bstar,f=s.jstar,h=s.astar,m=s.bstar,p=c+(f-c)*n,M=i+(h-i)*n,g=l+(m-l)*n;return L.fromUcs(p,M,g).toInt()}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class O{static ratioOfTones(e,r){return e=nt(0,100,e),r=nt(0,100,r),O.ratioOfYs(H(e),H(r))}static ratioOfYs(e,r){const n=e>r?e:r,a=n===r?e:r;return(n+5)/(a+5)}static lighter(e,r){if(e<0||e>100)return-1;const n=H(e),a=r*(n+5)-5,s=O.ratioOfYs(a,n),c=Math.abs(s-r);if(s<r&&c>.04)return-1;const i=ht(a)+.4;return i<0||i>100?-1:i}static darker(e,r){if(e<0||e>100)return-1;const n=H(e),a=(n+5)/r-5,s=O.ratioOfYs(n,a),c=Math.abs(s-r);if(s<r&&c>.04)return-1;const i=ht(a)-.4;return i<0||i>100?-1:i}static lighterUnsafe(e,r){const n=O.lighter(e,r);return n<0?100:n}static darkerUnsafe(e,r){const n=O.darker(e,r);return n<0?0:n}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class pt{static isDisliked(e){const r=Math.round(e.hue)>=90&&Math.round(e.hue)<=111,n=Math.round(e.chroma)>16,a=Math.round(e.tone)<65;return r&&n&&a}static fixIfDisliked(e){return pt.isDisliked(e)?R.from(e.hue,e.chroma,70):e}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class u{static fromPalette(e){return new u(e.name??"",e.palette,e.tone,e.isBackground??!1,e.background,e.secondBackground,e.contrastCurve,e.toneDeltaPair)}constructor(e,r,n,a,s,c,i,l){if(this.name=e,this.palette=r,this.tone=n,this.isBackground=a,this.background=s,this.secondBackground=c,this.contrastCurve=i,this.toneDeltaPair=l,this.hctCache=new Map,!s&&c)throw new Error(`Color ${e} has secondBackgrounddefined, but background is not defined.`);if(!s&&i)throw new Error(`Color ${e} has contrastCurvedefined, but background is not defined.`);if(s&&!i)throw new Error(`Color ${e} has backgrounddefined, but contrastCurve is not defined.`)}getArgb(e){return this.getHct(e).toInt()}getHct(e){const r=this.hctCache.get(e);if(r!=null)return r;const n=this.getTone(e),a=this.palette(e).getHct(n);return this.hctCache.size>4&&this.hctCache.clear(),this.hctCache.set(e,a),a}getTone(e){const r=e.contrastLevel<0;if(this.toneDeltaPair){const n=this.toneDeltaPair(e),a=n.roleA,s=n.roleB,c=n.delta,i=n.polarity,l=n.stayTogether,h=this.background(e).getTone(e),m=i==="nearer"||i==="lighter"&&!e.isDark||i==="darker"&&e.isDark,p=m?a:s,M=m?s:a,g=this.name===p.name,b=e.isDark?1:-1,C=p.contrastCurve.getContrast(e.contrastLevel),w=M.contrastCurve.getContrast(e.contrastLevel),I=p.tone(e);let P=O.ratioOfTones(h,I)>=C?I:u.foregroundTone(h,C);const N=M.tone(e);let k=O.ratioOfTones(h,N)>=w?N:u.foregroundTone(h,w);return r&&(P=u.foregroundTone(h,C),k=u.foregroundTone(h,w)),(k-P)*b>=c||(k=nt(0,100,P+c*b),(k-P)*b>=c||(P=nt(0,100,k-c*b))),50<=P&&P<60?b>0?(P=60,k=Math.max(k,P+c*b)):(P=49,k=Math.min(k,P+c*b)):50<=k&&k<60&&(l?b>0?(P=60,k=Math.max(k,P+c*b)):(P=49,k=Math.min(k,P+c*b)):b>0?k=60:k=49),g?P:k}else{let n=this.tone(e);if(this.background==null)return n;const a=this.background(e).getTone(e),s=this.contrastCurve.getContrast(e.contrastLevel);if(O.ratioOfTones(a,n)>=s||(n=u.foregroundTone(a,s)),r&&(n=u.foregroundTone(a,s)),this.isBackground&&50<=n&&n<60&&(O.ratioOfTones(49,a)>=s?n=49:n=60),this.secondBackground){const[c,i]=[this.background,this.secondBackground],[l,f]=[c(e).getTone(e),i(e).getTone(e)],[h,m]=[Math.max(l,f),Math.min(l,f)];if(O.ratioOfTones(h,n)>=s&&O.ratioOfTones(m,n)>=s)return n;const p=O.lighter(h,s),M=O.darker(m,s),g=[];return p!==-1&&g.push(p),M!==-1&&g.push(M),u.tonePrefersLightForeground(l)||u.tonePrefersLightForeground(f)?p<0?100:p:g.length===1?g[0]:M<0?0:M}return n}}static foregroundTone(e,r){const n=O.lighterUnsafe(e,r),a=O.darkerUnsafe(e,r),s=O.ratioOfTones(n,e),c=O.ratioOfTones(a,e);if(u.tonePrefersLightForeground(e)){const l=Math.abs(s-c)<.1&&s<r&&c<r;return s>=r||s>=c||l?n:a}else return c>=r||c>=s?a:n}static tonePrefersLightForeground(e){return Math.round(e)<60}static toneAllowsLightForeground(e){return Math.round(e)<=49}static enableLightForeground(e){return u.tonePrefersLightForeground(e)&&!u.toneAllowsLightForeground(e)?49:e}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */var Q;(function(t){t[t.MONOCHROME=0]="MONOCHROME",t[t.NEUTRAL=1]="NEUTRAL",t[t.TONAL_SPOT=2]="TONAL_SPOT",t[t.VIBRANT=3]="VIBRANT",t[t.EXPRESSIVE=4]="EXPRESSIVE",t[t.FIDELITY=5]="FIDELITY",t[t.CONTENT=6]="CONTENT",t[t.RAINBOW=7]="RAINBOW",t[t.FRUIT_SALAD=8]="FRUIT_SALAD"})(Q||(Q={}));/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class y{constructor(e,r,n,a){this.low=e,this.normal=r,this.medium=n,this.high=a}getContrast(e){return e<=-1?this.low:e<0?Z(this.low,this.normal,(e- -1)/1):e<.5?Z(this.normal,this.medium,(e-0)/.5):e<1?Z(this.medium,this.high,(e-.5)/.5):this.high}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class V{constructor(e,r,n,a,s){this.roleA=e,this.roleB=r,this.delta=n,this.polarity=a,this.stayTogether=s}}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function W(t){return t.variant===Q.FIDELITY||t.variant===Q.CONTENT}function T(t){return t.variant===Q.MONOCHROME}function Yt(t,e,r,n){let a=r,s=R.from(t,e,r);if(s.chroma<e){let c=s.chroma;for(;s.chroma<e;){a+=n?-1:1;const i=R.from(t,e,a);if(c>i.chroma||Math.abs(i.chroma-e)<.4)break;const l=Math.abs(i.chroma-e),f=Math.abs(s.chroma-e);l<f&&(s=i),c=Math.max(c,i.chroma)}}return a}function _t(t){return q.make(void 0,void 0,t.isDark?30:80,void 0,void 0)}function gt(t,e){const r=t.inViewingConditions(_t(e));return u.tonePrefersLightForeground(t.tone)&&!u.toneAllowsLightForeground(r.tone)?u.enableLightForeground(t.tone):u.enableLightForeground(r.tone)}class o{static highestSurface(e){return e.isDark?o.surfaceBright:o.surfaceDim}}o.contentAccentToneDelta=15;o.primaryPaletteKeyColor=u.fromPalette({name:"primary_palette_key_color",palette:t=>t.primaryPalette,tone:t=>t.primaryPalette.keyColor.tone});o.secondaryPaletteKeyColor=u.fromPalette({name:"secondary_palette_key_color",palette:t=>t.secondaryPalette,tone:t=>t.secondaryPalette.keyColor.tone});o.tertiaryPaletteKeyColor=u.fromPalette({name:"tertiary_palette_key_color",palette:t=>t.tertiaryPalette,tone:t=>t.tertiaryPalette.keyColor.tone});o.neutralPaletteKeyColor=u.fromPalette({name:"neutral_palette_key_color",palette:t=>t.neutralPalette,tone:t=>t.neutralPalette.keyColor.tone});o.neutralVariantPaletteKeyColor=u.fromPalette({name:"neutral_variant_palette_key_color",palette:t=>t.neutralVariantPalette,tone:t=>t.neutralVariantPalette.keyColor.tone});o.background=u.fromPalette({name:"background",palette:t=>t.neutralPalette,tone:t=>t.isDark?6:98,isBackground:!0});o.onBackground=u.fromPalette({name:"on_background",palette:t=>t.neutralPalette,tone:t=>t.isDark?90:10,background:t=>o.background,contrastCurve:new y(3,3,4.5,7)});o.surface=u.fromPalette({name:"surface",palette:t=>t.neutralPalette,tone:t=>t.isDark?6:98,isBackground:!0});o.surfaceDim=u.fromPalette({name:"surface_dim",palette:t=>t.neutralPalette,tone:t=>t.isDark?6:87,isBackground:!0});o.surfaceBright=u.fromPalette({name:"surface_bright",palette:t=>t.neutralPalette,tone:t=>t.isDark?24:98,isBackground:!0});o.surfaceContainerLowest=u.fromPalette({name:"surface_container_lowest",palette:t=>t.neutralPalette,tone:t=>t.isDark?4:100,isBackground:!0});o.surfaceContainerLow=u.fromPalette({name:"surface_container_low",palette:t=>t.neutralPalette,tone:t=>t.isDark?10:96,isBackground:!0});o.surfaceContainer=u.fromPalette({name:"surface_container",palette:t=>t.neutralPalette,tone:t=>t.isDark?12:94,isBackground:!0});o.surfaceContainerHigh=u.fromPalette({name:"surface_container_high",palette:t=>t.neutralPalette,tone:t=>t.isDark?17:92,isBackground:!0});o.surfaceContainerHighest=u.fromPalette({name:"surface_container_highest",palette:t=>t.neutralPalette,tone:t=>t.isDark?22:90,isBackground:!0});o.onSurface=u.fromPalette({name:"on_surface",palette:t=>t.neutralPalette,tone:t=>t.isDark?90:10,background:t=>o.highestSurface(t),contrastCurve:new y(4.5,7,11,21)});o.surfaceVariant=u.fromPalette({name:"surface_variant",palette:t=>t.neutralVariantPalette,tone:t=>t.isDark?30:90,isBackground:!0});o.onSurfaceVariant=u.fromPalette({name:"on_surface_variant",palette:t=>t.neutralVariantPalette,tone:t=>t.isDark?80:30,background:t=>o.highestSurface(t),contrastCurve:new y(3,4.5,7,11)});o.inverseSurface=u.fromPalette({name:"inverse_surface",palette:t=>t.neutralPalette,tone:t=>t.isDark?90:20});o.inverseOnSurface=u.fromPalette({name:"inverse_on_surface",palette:t=>t.neutralPalette,tone:t=>t.isDark?20:95,background:t=>o.inverseSurface,contrastCurve:new y(4.5,7,11,21)});o.outline=u.fromPalette({name:"outline",palette:t=>t.neutralVariantPalette,tone:t=>t.isDark?60:50,background:t=>o.highestSurface(t),contrastCurve:new y(1.5,3,4.5,7)});o.outlineVariant=u.fromPalette({name:"outline_variant",palette:t=>t.neutralVariantPalette,tone:t=>t.isDark?30:80,background:t=>o.highestSurface(t),contrastCurve:new y(1,1,3,7)});o.shadow=u.fromPalette({name:"shadow",palette:t=>t.neutralPalette,tone:t=>0});o.scrim=u.fromPalette({name:"scrim",palette:t=>t.neutralPalette,tone:t=>0});o.surfaceTint=u.fromPalette({name:"surface_tint",palette:t=>t.primaryPalette,tone:t=>t.isDark?80:40,isBackground:!0});o.primary=u.fromPalette({name:"primary",palette:t=>t.primaryPalette,tone:t=>T(t)?t.isDark?100:0:t.isDark?80:40,isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(3,4.5,7,11),toneDeltaPair:t=>new V(o.primaryContainer,o.primary,15,"nearer",!1)});o.onPrimary=u.fromPalette({name:"on_primary",palette:t=>t.primaryPalette,tone:t=>T(t)?t.isDark?10:90:t.isDark?20:100,background:t=>o.primary,contrastCurve:new y(4.5,7,11,21)});o.primaryContainer=u.fromPalette({name:"primary_container",palette:t=>t.primaryPalette,tone:t=>W(t)?gt(t.sourceColorHct,t):T(t)?t.isDark?85:25:t.isDark?30:90,isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(1,1,3,7),toneDeltaPair:t=>new V(o.primaryContainer,o.primary,15,"nearer",!1)});o.onPrimaryContainer=u.fromPalette({name:"on_primary_container",palette:t=>t.primaryPalette,tone:t=>W(t)?u.foregroundTone(o.primaryContainer.tone(t),4.5):T(t)?t.isDark?0:100:t.isDark?90:10,background:t=>o.primaryContainer,contrastCurve:new y(4.5,7,11,21)});o.inversePrimary=u.fromPalette({name:"inverse_primary",palette:t=>t.primaryPalette,tone:t=>t.isDark?40:80,background:t=>o.inverseSurface,contrastCurve:new y(3,4.5,7,11)});o.secondary=u.fromPalette({name:"secondary",palette:t=>t.secondaryPalette,tone:t=>t.isDark?80:40,isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(3,4.5,7,11),toneDeltaPair:t=>new V(o.secondaryContainer,o.secondary,15,"nearer",!1)});o.onSecondary=u.fromPalette({name:"on_secondary",palette:t=>t.secondaryPalette,tone:t=>T(t)?t.isDark?10:100:t.isDark?20:100,background:t=>o.secondary,contrastCurve:new y(4.5,7,11,21)});o.secondaryContainer=u.fromPalette({name:"secondary_container",palette:t=>t.secondaryPalette,tone:t=>{const e=t.isDark?30:90;if(T(t))return t.isDark?30:85;if(!W(t))return e;let r=Yt(t.secondaryPalette.hue,t.secondaryPalette.chroma,e,!t.isDark);return r=gt(t.secondaryPalette.getHct(r),t),r},isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(1,1,3,7),toneDeltaPair:t=>new V(o.secondaryContainer,o.secondary,15,"nearer",!1)});o.onSecondaryContainer=u.fromPalette({name:"on_secondary_container",palette:t=>t.secondaryPalette,tone:t=>W(t)?u.foregroundTone(o.secondaryContainer.tone(t),4.5):t.isDark?90:10,background:t=>o.secondaryContainer,contrastCurve:new y(4.5,7,11,21)});o.tertiary=u.fromPalette({name:"tertiary",palette:t=>t.tertiaryPalette,tone:t=>T(t)?t.isDark?90:25:t.isDark?80:40,isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(3,4.5,7,11),toneDeltaPair:t=>new V(o.tertiaryContainer,o.tertiary,15,"nearer",!1)});o.onTertiary=u.fromPalette({name:"on_tertiary",palette:t=>t.tertiaryPalette,tone:t=>T(t)?t.isDark?10:90:t.isDark?20:100,background:t=>o.tertiary,contrastCurve:new y(4.5,7,11,21)});o.tertiaryContainer=u.fromPalette({name:"tertiary_container",palette:t=>t.tertiaryPalette,tone:t=>{if(T(t))return t.isDark?60:49;if(!W(t))return t.isDark?30:90;const e=gt(t.tertiaryPalette.getHct(t.sourceColorHct.tone),t),r=t.tertiaryPalette.getHct(e);return pt.fixIfDisliked(r).tone},isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(1,1,3,7),toneDeltaPair:t=>new V(o.tertiaryContainer,o.tertiary,15,"nearer",!1)});o.onTertiaryContainer=u.fromPalette({name:"on_tertiary_container",palette:t=>t.tertiaryPalette,tone:t=>T(t)?t.isDark?0:100:W(t)?u.foregroundTone(o.tertiaryContainer.tone(t),4.5):t.isDark?90:10,background:t=>o.tertiaryContainer,contrastCurve:new y(4.5,7,11,21)});o.error=u.fromPalette({name:"error",palette:t=>t.errorPalette,tone:t=>t.isDark?80:40,isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(3,4.5,7,11),toneDeltaPair:t=>new V(o.errorContainer,o.error,15,"nearer",!1)});o.onError=u.fromPalette({name:"on_error",palette:t=>t.errorPalette,tone:t=>t.isDark?20:100,background:t=>o.error,contrastCurve:new y(4.5,7,11,21)});o.errorContainer=u.fromPalette({name:"error_container",palette:t=>t.errorPalette,tone:t=>t.isDark?30:90,isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(1,1,3,7),toneDeltaPair:t=>new V(o.errorContainer,o.error,15,"nearer",!1)});o.onErrorContainer=u.fromPalette({name:"on_error_container",palette:t=>t.errorPalette,tone:t=>t.isDark?90:10,background:t=>o.errorContainer,contrastCurve:new y(4.5,7,11,21)});o.primaryFixed=u.fromPalette({name:"primary_fixed",palette:t=>t.primaryPalette,tone:t=>T(t)?40:90,isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(1,1,3,7),toneDeltaPair:t=>new V(o.primaryFixed,o.primaryFixedDim,10,"lighter",!0)});o.primaryFixedDim=u.fromPalette({name:"primary_fixed_dim",palette:t=>t.primaryPalette,tone:t=>T(t)?30:80,isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(1,1,3,7),toneDeltaPair:t=>new V(o.primaryFixed,o.primaryFixedDim,10,"lighter",!0)});o.onPrimaryFixed=u.fromPalette({name:"on_primary_fixed",palette:t=>t.primaryPalette,tone:t=>T(t)?100:10,background:t=>o.primaryFixedDim,secondBackground:t=>o.primaryFixed,contrastCurve:new y(4.5,7,11,21)});o.onPrimaryFixedVariant=u.fromPalette({name:"on_primary_fixed_variant",palette:t=>t.primaryPalette,tone:t=>T(t)?90:30,background:t=>o.primaryFixedDim,secondBackground:t=>o.primaryFixed,contrastCurve:new y(3,4.5,7,11)});o.secondaryFixed=u.fromPalette({name:"secondary_fixed",palette:t=>t.secondaryPalette,tone:t=>T(t)?80:90,isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(1,1,3,7),toneDeltaPair:t=>new V(o.secondaryFixed,o.secondaryFixedDim,10,"lighter",!0)});o.secondaryFixedDim=u.fromPalette({name:"secondary_fixed_dim",palette:t=>t.secondaryPalette,tone:t=>T(t)?70:80,isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(1,1,3,7),toneDeltaPair:t=>new V(o.secondaryFixed,o.secondaryFixedDim,10,"lighter",!0)});o.onSecondaryFixed=u.fromPalette({name:"on_secondary_fixed",palette:t=>t.secondaryPalette,tone:t=>10,background:t=>o.secondaryFixedDim,secondBackground:t=>o.secondaryFixed,contrastCurve:new y(4.5,7,11,21)});o.onSecondaryFixedVariant=u.fromPalette({name:"on_secondary_fixed_variant",palette:t=>t.secondaryPalette,tone:t=>T(t)?25:30,background:t=>o.secondaryFixedDim,secondBackground:t=>o.secondaryFixed,contrastCurve:new y(3,4.5,7,11)});o.tertiaryFixed=u.fromPalette({name:"tertiary_fixed",palette:t=>t.tertiaryPalette,tone:t=>T(t)?40:90,isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(1,1,3,7),toneDeltaPair:t=>new V(o.tertiaryFixed,o.tertiaryFixedDim,10,"lighter",!0)});o.tertiaryFixedDim=u.fromPalette({name:"tertiary_fixed_dim",palette:t=>t.tertiaryPalette,tone:t=>T(t)?30:80,isBackground:!0,background:t=>o.highestSurface(t),contrastCurve:new y(1,1,3,7),toneDeltaPair:t=>new V(o.tertiaryFixed,o.tertiaryFixedDim,10,"lighter",!0)});o.onTertiaryFixed=u.fromPalette({name:"on_tertiary_fixed",palette:t=>t.tertiaryPalette,tone:t=>T(t)?100:10,background:t=>o.tertiaryFixedDim,secondBackground:t=>o.tertiaryFixed,contrastCurve:new y(4.5,7,11,21)});o.onTertiaryFixedVariant=u.fromPalette({name:"on_tertiary_fixed_variant",palette:t=>t.tertiaryPalette,tone:t=>T(t)?90:30,background:t=>o.tertiaryFixedDim,secondBackground:t=>o.tertiaryFixed,contrastCurve:new y(3,4.5,7,11)});/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class E{static fromInt(e){const r=R.fromInt(e);return E.fromHct(r)}static fromHct(e){return new E(e.hue,e.chroma,e)}static fromHueAndChroma(e,r){return new E(e,r,E.createKeyColor(e,r))}constructor(e,r,n){this.hue=e,this.chroma=r,this.keyColor=n,this.cache=new Map}static createKeyColor(e,r){let a=R.from(e,r,50),s=Math.abs(a.chroma-r);for(let c=1;c<50;c+=1){if(Math.round(r)===Math.round(a.chroma))return a;const i=R.from(e,r,50+c),l=Math.abs(i.chroma-r);l<s&&(s=l,a=i);const f=R.from(e,r,50-c),h=Math.abs(f.chroma-r);h<s&&(s=h,a=f)}return a}tone(e){let r=this.cache.get(e);return r===void 0&&(r=R.from(this.hue,this.chroma,e).toInt(),this.cache.set(e,r)),r}getHct(e){return R.fromInt(this.tone(e))}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class S{static of(e){return new S(e,!1)}static contentOf(e){return new S(e,!0)}static fromColors(e){return S.createPaletteFromColors(!1,e)}static contentFromColors(e){return S.createPaletteFromColors(!0,e)}static createPaletteFromColors(e,r){const n=new S(r.primary,e);if(r.secondary){const a=new S(r.secondary,e);n.a2=a.a1}if(r.tertiary){const a=new S(r.tertiary,e);n.a3=a.a1}if(r.error){const a=new S(r.error,e);n.error=a.a1}if(r.neutral){const a=new S(r.neutral,e);n.n1=a.n1}if(r.neutralVariant){const a=new S(r.neutralVariant,e);n.n2=a.n2}return n}constructor(e,r){const n=R.fromInt(e),a=n.hue,s=n.chroma;r?(this.a1=E.fromHueAndChroma(a,s),this.a2=E.fromHueAndChroma(a,s/3),this.a3=E.fromHueAndChroma(a+60,s/2),this.n1=E.fromHueAndChroma(a,Math.min(s/12,4)),this.n2=E.fromHueAndChroma(a,Math.min(s/6,8))):(this.a1=E.fromHueAndChroma(a,Math.max(48,s)),this.a2=E.fromHueAndChroma(a,16),this.a3=E.fromHueAndChroma(a+60,24),this.n1=E.fromHueAndChroma(a,4),this.n2=E.fromHueAndChroma(a,8)),this.error=E.fromHueAndChroma(25,84)}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class G{get primary(){return this.props.primary}get onPrimary(){return this.props.onPrimary}get primaryContainer(){return this.props.primaryContainer}get onPrimaryContainer(){return this.props.onPrimaryContainer}get secondary(){return this.props.secondary}get onSecondary(){return this.props.onSecondary}get secondaryContainer(){return this.props.secondaryContainer}get onSecondaryContainer(){return this.props.onSecondaryContainer}get tertiary(){return this.props.tertiary}get onTertiary(){return this.props.onTertiary}get tertiaryContainer(){return this.props.tertiaryContainer}get onTertiaryContainer(){return this.props.onTertiaryContainer}get error(){return this.props.error}get onError(){return this.props.onError}get errorContainer(){return this.props.errorContainer}get onErrorContainer(){return this.props.onErrorContainer}get background(){return this.props.background}get onBackground(){return this.props.onBackground}get surface(){return this.props.surface}get onSurface(){return this.props.onSurface}get surfaceVariant(){return this.props.surfaceVariant}get onSurfaceVariant(){return this.props.onSurfaceVariant}get outline(){return this.props.outline}get outlineVariant(){return this.props.outlineVariant}get shadow(){return this.props.shadow}get scrim(){return this.props.scrim}get inverseSurface(){return this.props.inverseSurface}get inverseOnSurface(){return this.props.inverseOnSurface}get inversePrimary(){return this.props.inversePrimary}static light(e){return G.lightFromCorePalette(S.of(e))}static dark(e){return G.darkFromCorePalette(S.of(e))}static lightContent(e){return G.lightFromCorePalette(S.contentOf(e))}static darkContent(e){return G.darkFromCorePalette(S.contentOf(e))}static lightFromCorePalette(e){return new G({primary:e.a1.tone(40),onPrimary:e.a1.tone(100),primaryContainer:e.a1.tone(90),onPrimaryContainer:e.a1.tone(10),secondary:e.a2.tone(40),onSecondary:e.a2.tone(100),secondaryContainer:e.a2.tone(90),onSecondaryContainer:e.a2.tone(10),tertiary:e.a3.tone(40),onTertiary:e.a3.tone(100),tertiaryContainer:e.a3.tone(90),onTertiaryContainer:e.a3.tone(10),error:e.error.tone(40),onError:e.error.tone(100),errorContainer:e.error.tone(90),onErrorContainer:e.error.tone(10),background:e.n1.tone(99),onBackground:e.n1.tone(10),surface:e.n1.tone(99),onSurface:e.n1.tone(10),surfaceVariant:e.n2.tone(90),onSurfaceVariant:e.n2.tone(30),outline:e.n2.tone(50),outlineVariant:e.n2.tone(80),shadow:e.n1.tone(0),scrim:e.n1.tone(0),inverseSurface:e.n1.tone(20),inverseOnSurface:e.n1.tone(95),inversePrimary:e.a1.tone(80)})}static darkFromCorePalette(e){return new G({primary:e.a1.tone(80),onPrimary:e.a1.tone(20),primaryContainer:e.a1.tone(30),onPrimaryContainer:e.a1.tone(90),secondary:e.a2.tone(80),onSecondary:e.a2.tone(20),secondaryContainer:e.a2.tone(30),onSecondaryContainer:e.a2.tone(90),tertiary:e.a3.tone(80),onTertiary:e.a3.tone(20),tertiaryContainer:e.a3.tone(30),onTertiaryContainer:e.a3.tone(90),error:e.error.tone(80),onError:e.error.tone(20),errorContainer:e.error.tone(30),onErrorContainer:e.error.tone(80),background:e.n1.tone(10),onBackground:e.n1.tone(90),surface:e.n1.tone(10),onSurface:e.n1.tone(90),surfaceVariant:e.n2.tone(30),onSurfaceVariant:e.n2.tone(80),outline:e.n2.tone(60),outlineVariant:e.n2.tone(30),shadow:e.n1.tone(0),scrim:e.n1.tone(0),inverseSurface:e.n1.tone(90),inverseOnSurface:e.n1.tone(20),inversePrimary:e.a1.tone(40)})}constructor(e){this.props=e}toJSON(){return{...this.props}}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function Ft(t){const e=Mt(t),r=Ct(t),n=Dt(t),a=[e.toString(16),r.toString(16),n.toString(16)];for(const[s,c]of a.entries())c.length===1&&(a[s]="0"+c);return"#"+a.join("")}function Gt(t){t=t.replace("#","");const e=t.length===3,r=t.length===6,n=t.length===8;if(!e&&!r&&!n)throw new Error("unexpected hex "+t);let a=0,s=0,c=0;return e?(a=j(t.slice(0,1).repeat(2)),s=j(t.slice(1,2).repeat(2)),c=j(t.slice(2,3).repeat(2))):r?(a=j(t.slice(0,2)),s=j(t.slice(2,4)),c=j(t.slice(4,6))):n&&(a=j(t.slice(2,4)),s=j(t.slice(4,6)),c=j(t.slice(6,8))),(255<<24|(a&255)<<16|(s&255)<<8|c&255)>>>0}function j(t){return parseInt(t,16)}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function $t(t,e=[]){const r=S.of(t);return{source:t,schemes:{light:G.light(t),dark:G.dark(t)},palettes:{primary:r.a1,secondary:r.a2,tertiary:r.a3,neutral:r.n1,neutralVariant:r.n2,error:r.error},customColors:e.map(n=>jt(t,n))}}function jt(t,e){let r=e.value;const n=r,a=t;e.blend&&(r=mt.harmonize(n,a));const c=S.of(r).a1;return{color:e,value:r,light:{color:c.tone(40),onColor:c.tone(100),colorContainer:c.tone(90),onColorContainer:c.tone(10)},dark:{color:c.tone(80),onColor:c.tone(20),colorContainer:c.tone(30),onColorContainer:c.tone(90)}}}function Jt(t,e){const r=(e==null?void 0:e.target)||document.body,a=(e==null?void 0:e.dark)??!1?t.schemes.dark:t.schemes.light;if(it(r,a),e!=null&&e.brightnessSuffix&&(it(r,t.schemes.dark,"-dark"),it(r,t.schemes.light,"-light")),e!=null&&e.paletteTones){const s=(e==null?void 0:e.paletteTones)??[];for(const[c,i]of Object.entries(t.palettes)){const l=c.replace(/([a-z])([A-Z])/g,"$1-$2").toLowerCase();for(const f of s){const h=`--md-ref-palette-${l}-${l}${f}`,m=Ft(i.tone(f));r.style.setProperty(h,m)}}}}function it(t,e,r=""){for(const[n,a]of Object.entries(e.toJSON())){const s=n.replace(/([a-z])([A-Z])/g,"$1-$2").toLowerCase(),c=Ft(a);t.style.setProperty(`--md-sys-color-${s}${r}`,c)}}export{Gt as a,Jt as b,$t as t};
